/*
 * Copyright (c) 2015, NVIDIA CORPORATION. All rights reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#include <linux/module.h>
#include <linux/slab.h>
#include <linux/err.h>

#include "nvidia-drm-os-interface.h"
#include "nvidia-drm.h"

#include "conftest.h"

#if defined(NV_DRM_AVAILABLE)

#include "nv-mm.h"
#include "nv-pgprot.h"

MODULE_PARM_DESC(
    modeset,
    "Enable atomic kernel modesetting (1 = enable, 0 = disable (default))");
bool nvidia_drm_modeset_module_param = false;
module_param_named(modeset, nvidia_drm_modeset_module_param, bool, 0400);

void *nvidia_drm_calloc(size_t nmemb, size_t size)
{
    return kzalloc(nmemb * size, GFP_KERNEL);
}

void nvidia_drm_free(void *ptr)
{
    if (IS_ERR(ptr))
    {
        return;
    }

    kfree(ptr);
}

char *nvidia_drm_asprintf(const char *fmt, ...)
{
    va_list ap;
    char *p;

    va_start(ap, fmt);
    p = kvasprintf(GFP_KERNEL, fmt, ap);
    va_end(ap);

    return p;
}

int nvidia_drm_encode_pgprot(enum nvidia_drm_memory_cache_type cache_type,
                             pgprot_t *prot)
{
    switch (cache_type) {
        case NV_DRM_MEMORY_CACHE_TYPE_UNCACHED_WEAK:
#if defined(NV_PGPROT_UNCACHED_WEAK)
            *prot = NV_PGPROT_UNCACHED_WEAK(*prot);
            break;
#endif
        case NV_DRM_MEMORY_CACHE_TYPE_UNCACHED:
            *prot = NV_PGPROT_UNCACHED_DEVICE(*prot);
            break;
        case NV_DRM_MEMORY_CACHE_TYPE_WRITECOMBINED:
#if defined(NV_PGPROT_WRITE_COMBINED_DEVICE)
            *prot = NV_PGPROT_WRITE_COMBINED_DEVICE(*prot);
            break;
#endif
        default:
            return -EINVAL;
    }

    return 0;
}

#if defined(NVCPU_X86) || defined(NVCPU_X86_64)
  #define WRITE_COMBINE_FLUSH()    asm volatile("sfence":::"memory")
#elif defined(NVCPU_FAMILY_ARM)
  #if defined(NVCPU_ARM)
    #define WRITE_COMBINE_FLUSH()  { dsb(); outer_sync(); }
  #elif defined(NVCPU_AARCH64)
    #define WRITE_COMBINE_FLUSH()  mb()
  #endif
#elif defined(NVCPU_PPC64LE)
  #define WRITE_COMBINE_FLUSH()    asm volatile("sync":::"memory")
#endif

void nvidia_drm_write_combine_flush(void)
{
    WRITE_COMBINE_FLUSH();
}

int nvidia_drm_remap_pfn_range(struct vm_area_struct *vma,
                               unsigned long virt_addr, unsigned long phys_addr,
                               unsigned long size, pgprot_t prot)
{
#if defined(NV_REMAP_PFN_RANGE_PRESENT)
    return remap_pfn_range(vma, virt_addr, phys_addr, size, prot);
#else
    return remap_page_range(vma, virt_addr, phys_addr, size, prot);
#endif
}

int nvidia_drm_lock_user_pages(unsigned long address,
                               unsigned long pages_count, struct page ***pages)
{
    struct mm_struct *mm = current->mm;
    struct page **user_pages;
    const int write = 1;
    const int force = 0;
    int pages_pinned;

    user_pages = nvidia_drm_calloc(pages_count, sizeof(*user_pages));

    if (user_pages == NULL)
    {
        return -ENOMEM;
    }

    down_read(&mm->mmap_sem);

    pages_pinned = NV_GET_USER_PAGES(address, pages_count, write, force,
                                     user_pages, NULL);
    up_read(&mm->mmap_sem);

    if (pages_pinned < 0 || (unsigned)pages_pinned < pages_count)
    {
        goto failed;
    }

    *pages = user_pages;

    return 0;

failed:

    if (pages_pinned > 0)
    {
        int i;

        for (i = 0; i < pages_pinned; i++)
        {
            put_page(user_pages[i]);
        }
    }

    nvidia_drm_free(user_pages);

    return (pages_pinned < 0) ? pages_pinned : -EINVAL;
}

void nvidia_drm_unlock_user_pages(unsigned long  pages_count,
                                  struct page **pages)
{
    unsigned long i;

    for (i = 0; i < pages_count; i++)
    {
        set_page_dirty_lock(pages[i]);

        put_page(pages[i]);
    }

    nvidia_drm_free(pages);
}

void *nvidia_drm_vmap(struct page **pages, unsigned long pages_count)
{
    return vmap(pages, pages_count, VM_USERMAP, PAGE_KERNEL);
}

void nvidia_drm_vunmap(void *address)
{
    vunmap(address);
}

uint64_t nvidia_drm_get_time_usec(void)
{
    struct timeval tv;

    do_gettimeofday(&tv);

    return (((uint64_t)tv.tv_sec) * 1000000) + tv.tv_usec;
}

#endif /* NV_DRM_AVAILABLE */

/*************************************************************************
 * Linux loading support code.
 *************************************************************************/

static int __init nv_linux_drm_init(void)
{
    return nv_drm_init();
}

static void __exit nv_linux_drm_exit(void)
{
    nv_drm_exit();
}

module_init(nv_linux_drm_init);
module_exit(nv_linux_drm_exit);

#if defined(MODULE_LICENSE)
  MODULE_LICENSE("MIT");
#endif
#if defined(MODULE_INFO)
  MODULE_INFO(supported, "external");
#endif
#if defined(MODULE_VERSION)
  MODULE_VERSION(NV_VERSION_STRING);
#endif
