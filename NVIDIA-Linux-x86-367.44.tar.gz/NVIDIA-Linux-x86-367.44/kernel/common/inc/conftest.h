#ifndef _CONFTEST_H
#define _CONFTEST_H

#include "conftest/headers.h"
#include "conftest/functions.h"
#include "conftest/generic.h"
#include "conftest/macros.h"
#include "conftest/symbols.h"
#include "conftest/types.h"

#endif
